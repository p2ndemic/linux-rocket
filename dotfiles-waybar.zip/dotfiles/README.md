# Dotfiles for openSUSE Tumbleweed

## Disclaimer:
Just a my personal niri setup on two devices:

- Custom build PC (AMD)
- Lenovo Yoga 7 2-in-1 14AHP9 (AMD)

The files should work on both machines. Maybe you have to chance minor things for yourself, like apps.

**Use at unkown risk!**

## Used software:
- Niri (https://github.com/YaLTeR/niri)
- Waybar (https://github.com/Alexays/Waybar)
- Fuzzel (https://codeberg.org/dnkl/fuzzel)
- Swayidle (https://github.com/swaywm/swayidle)
- Kitty (https://sw.kovidgoyal.net/kitty/)
- SwayNC (https://github.com/ErikReider/SwayNotificationCenter)
- Helix (https://helix-editor.com/)
- Fastfetch (https://github.com/fastfetch-cli/fastfetch)
- wlogout (https://github.com/ArtsyMacaw/wlogout)

## I got inspired by a lot of stuff from the internet, like ...
- colors based on adwaita
- Papirus Icons (used in wlogout)
- mylinuxforwork ... great dotfiles for inspiration (https://github.com/mylinuxforwork)
- in case, that I forgot someone ... just say it :)
- opensuse icon belongs to (https://opensuse.org) and is a modified papirus icon

## needed Fonts and Icons
- fonts-fontawesome
- symbols-only-nerd-fonts
- Papirus / Papirus-dark for icons

## Installation:
- config belongs in ~/.config
- don't forget to chmod +x the script in config/bin

## Niri Bindings

Press **Mod+Alt+H** to display keybindings.

## Screenshot
![Screenshot Niri](screenshot.png)

### Have fun!
