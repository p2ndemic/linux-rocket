#!/bin/bash

export common=(
"git"
)
export fedora=(
"python3-pip"
"yarnpkg"
"yarnpkg"
"nodejs"
"dnfdragora"
"nodejs-npm"
)
export arch=(
"python-pip"
"flatpak"
"yarn"
"nodejs-lts-fermium"
"lure-bin"
"npm"
)
