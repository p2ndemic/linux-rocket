#!/bin/bash

export common=(
    "zsh"
    "fzf"
)
export fedora=(
    "util-linux-user"
)
export arch=(
)
