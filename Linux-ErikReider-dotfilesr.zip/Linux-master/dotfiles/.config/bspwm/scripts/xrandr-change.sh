feh --bg-scale ~/.cache/wallpaper &

# Set the mouse sensitivity
~/.config/bspwm/scripts/mouseSensitivity.sh &

# Start the compsitor
~/.config/picom/startPicom.sh &

