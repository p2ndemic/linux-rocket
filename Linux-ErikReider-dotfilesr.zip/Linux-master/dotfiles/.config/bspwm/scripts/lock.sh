#!/bin/sh
i3lock-fancy-rapid 10 10 -t --ignore-empty-password --show-failed-attempts --nofork -p default
