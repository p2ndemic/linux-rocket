return {
    {
        "norcalli/nvim-colorizer.lua",
        main = "colorizer",
        opts = {
            -- Enable for all filetypes.
            -- Gets disabled when lsp supports document_color in on_attach.
            "*",
        },
    },
}
