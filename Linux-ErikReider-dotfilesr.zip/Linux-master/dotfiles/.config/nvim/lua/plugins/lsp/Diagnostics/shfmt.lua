return { formatCommand = "shfmt -ci -s -bn -i 4", formatStdin = true }
