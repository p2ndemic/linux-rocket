return {
    -- a list of all tools you want to ensure are installed upon
    -- start; they should be the names Mason uses for each tool
    ensure_installed = {
        -- LSPs
        { "vala-language-server", version = "HEAD" },
        "bash-language-server",
        "shellcheck",
        "efm",
        "clangd",
        "lua-language-server",
        "vim-language-server",
        -- Note: Rust uses rustaceanvim instead with the natively packaged analyzer
        "css-lsp",
        "html-lsp",
        "json-lsp",
        "dockerfile-language-server",
        "emmet-language-server",
        "elixir-ls",
        "lemminx",
        "typescript-language-server",
        "stylelint-lsp",
        "basedpyright",
        "omnisharp",
        "texlab",
        "jdtls",
        "mesonlsp",
        "neocmakelsp",
        "zls",
        "glsl_analyzer",
        "intelephense",
        "gh-actions-language-server",
        -- NOTE: Fedora 42 doesn't ship Go 1.25 which is required by newer versions
        { "hyprls", version = "v0.8.0" },
        "yaml-language-server",
        "systemd-language-server",
        "ansible-language-server",

        -- Linters/Formatters
        "biome", -- Linter and formatter that replaces prettierd and eslint_d
        -- Linters
        -- TODO: Linters
        "vint",
        "markdownlint",
        "cpplint",
        "cspell",
        "actionlint",
        "systemdlint",
        "ansible-lint",

        -- Formatters
        "stylua",
        "black",
        "shfmt",
        -- TODO: Prettierd Plugins https://github.com/fsouza/prettierd#additional-plugins
        "prettierd",
        "clang-format",
        "latexindent",
    },
    auto_update = false,
}
