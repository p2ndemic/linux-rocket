-- Peek lines just when you intend (peek lines while entering command `:{number}`)
return { { "nacro90/numb.nvim", opts = {} } }
