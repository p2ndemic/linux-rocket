feh --bg-scale ~/.cache/wallpaper

# Set the mouse sensitivity
~/.config/i3/scripts/mouseSensitivity.sh

# Start the compsitor
~/.config/picom/startPicom.sh

# Start the panel
~/.config/polybar/launch.sh
